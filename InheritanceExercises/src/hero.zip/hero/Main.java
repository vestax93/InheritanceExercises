package hero;

public class Main {
    public static void main(String[] args) {
        DarkKnight darkKnight = new DarkKnight("Batman", 100);
        System.out.println(darkKnight);
    }
}
