package person;

public class Child extends Person{ //klasaChild nasledjuje klasu Person

    public Child(String name, int age) {
        super(name, age); //super nam oznacava da se radi o nadklasi konkretno u ovom primeru konstruktor nadklase
    }
}
