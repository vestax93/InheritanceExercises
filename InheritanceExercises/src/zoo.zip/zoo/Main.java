package zoo;

public class Main {
    public static void main(String[] args) {
        Bear bear = new Bear("Pooh");
        System.out.println(bear.getName());
    }
}
